# Copyright 2014 Google Inc. All Rights Reserved.

"""The command group for the Endpoints CLI."""

from googlecloudsdk.calliope import base


class Script(base.Group):
  """Manage your Endpoints project."""

